# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.

## what is done in this project by me is :

1.Creat navbar dynamiclly depending on number of sections
2.make navbar links default change to scroll to the target section not jump
3.add top button when scroll below fold of the page
4.Make sections collapsible.
5.Hide fixed navigation bar while not scrolling
6.add active state to section in viewport

